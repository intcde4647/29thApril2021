--records for customer_master
 
insert into customer_master values('C00001','Nitin','9830354218','A/122, Kalkaji','2012-10-15',22);
insert into customer_master values('C00002','Agnesh','8923156781','9/1,Andheri East','2012-11-01',35);
insert into customer_master values('C00003','T Ramachandran','9831289761','9/1,Nandabakkam','2012-11-02',25);
insert into customer_master values('C00004','Rajib Mitra','9830356781','H/56, Block1,Jadavpur','2012-11-21',45); 
insert into customer_master values('C00005','Shiv Prasad','8962198765','2/2 Phase II, Jawahar Nagar','2012-12-25',30); 
insert into customer_master values('C00006','Ajay Ghosh','8763478901','N/2,Gandhi Colony,Dum dum','2012-12-30',20); 
insert into customer_master values('C00007','Geetha Reddy','8976167890','AH 1/1 T Nagar','2012-12-31',30);
insert into customer_master values('C00008','Ria Natrajan','9856723190','A/B Gandhi Colony','2013-01-01',45);
insert into customer_master values('C00009','Rajan Pillai','8621349860','A 1/66 Kodambakkam','2013-01-02',40);
insert into customer_master values('C00010','Raghav Singh','9675167890','A/6 Nehru Jawahar Nagar','2013-03-02',50);
insert into customer_master values('C00011','Raj Sekhanran','8423178906','A/1 Mayur Kunj','2013-03-15',25);

--records for movies in the library

insert into movies_master values('M00001','Die Hard',1998,'English',4,120,'Universal','Action','John McTiernan','Bruce Willis', 'Bonnie Bedelia',100);
insert into movies_master values('M00002','The Dark Knight',2008,'English',5,90,'Parental Guidence','Action','Christopher Nolan','Christian Bale', 'Health Ledger',100);
insert into movies_master values('M00003','The Matrix',1999,'English',4,120,'Universal','Action','Andy Larry','Keanu Reeves', 'Carrie-Anee Moss',100);
insert into movies_master values('M00004','Inception',2010,'English',5,120,'Parental Guidence','Action','Christopher Nolan','Leonardo DiCaprio', 'Joseph Gordan',100);
insert into movies_master values('M00005','Office Space',1999,'English',4,95,'Universal','Comedy','Mike Judge','Ron Livingston', 'Jennifer Aniston',100);
insert into movies_master values('M00006','Young Frankenstein',1974,'English',4,130,'Universal','Comedy','Mel Brooks','Gene Wilder', 'Teri Garr',100);
insert into movies_master values('M00007','Shaun of the Dead',2004,'English',4,95,'Universal','Comedy','Edgar Wright','Simon Pegg', 'Kate Ashfield',100);
insert into movies_master values('M00008','Casablanca',1942,'English',3,120,'Universal','Romance','Michael Curtiz','Humprey Bogart', 'Ingrid Bergman',100);
insert into movies_master values('M00009','The Notebook',2004,'English',3,120,'Parental Guidence','Romance','Nick Cassavetes','Ryan Gosling', 'Rachel McAdams',100);
insert into movies_master values('M00010','Gone with the Wind',1939,'English',3,120,'Parental Guidence','Romance','Victor Flemming','Clark Gable', 'Vivien Leigh',100);
insert into movies_master values('M00011','Titanic',1997,'English',3,120,'Parental Guidence','Romance','James Cameron','Leonardo DiCaprio', 'Kate Winslet',100);


--records for types of cards 


insert into library_card_master values('CRD001','Silver Card',1000,1);
insert into library_card_master values('CRD002','Gold  Card',2000,2);
insert into library_card_master values('CRD003','Platinum  Card',3000,3);
insert into library_card_master values('CRD004','Diamond  Card',4000,5);


--records of customer and card details



insert into customer_issue_details values('I00001','C00001','M00001','2012-10-15','2012-10-17','2012-10-17');
insert into customer_issue_details values('I00002','C00002','M00002','2012-11-02','2012-11-04','2012-11-05');
insert into customer_issue_details values('I00003','C00002','M00002','2012-12-02','2012-12-04','2012-12-03');
insert into customer_issue_details values('I00004','C00003','M00003','2012-11-02','2012-11-04','2012-11-10');
insert into customer_issue_details values('I00005','C00003','M00004','2012-11-10','2012-11-12','2012-11-12');
insert into customer_issue_details values('I00006','C00003','M00005','2012-11-12','2012-11-14','2012-11-14');
insert into customer_issue_details values('I00007','C00004','M00006','2012-11-21','2012-11-23','2012-11-24');
insert into customer_issue_details values('I00008','C00010','M00008','2013-03-02','2013-03-04','2013-03-05');
insert into customer_issue_details values('I00009','C00011','M00010','2013-03-16','2013-03-18','2013-03-18');
insert into customer_issue_details values('I00010','C00004','M00007','2012-11-25','2012-11-27','2012-11-27');
insert into customer_issue_details values('I00011','C00004','M00007','2012-11-28','2012-11-30','2012-11-30');
insert into customer_issue_details values('I00012','C00001','M00001','2013-11-28','2013-11-30','2013-11-30');
insert into customer_issue_details values('I00013','C00003','M00001','2012-12-03','2012-12-05','2012-12-05');
insert into customer_issue_details values('I00014','C00003','M00010','2013-01-02','2013-01-04','2013-01-05');
insert into customer_issue_details values('I00015','C00003','M00011','2013-02-03','2013-02-05','2013-02-06');
insert into customer_issue_details values('I00016','C00003','M00011','2013-03-05','2013-03-07','2013-03-07');
insert into customer_issue_details values('I00017','C00003','M00008','2013-04-15','2013-04-17','2013-04-17');
insert into customer_issue_details values('I00018','C00002','M00010','2015-01-15','2015-01-17','2015-01-17');
insert into customer_issue_details values('I00019','C00004','M00001','2012-11-15','2012-11-17','2012-11-17');


--records for customer and card details


insert into customer_card_details values('C00001','CRD001','2012-10-15');
insert into customer_card_details values('C00002','CRD002','2012-12-01');
insert into customer_card_details values('C00003','CRD002','2012-11-02');
insert into customer_card_details values('C00004','CRD003','2012-11-21');
insert into customer_card_details values('C00005','CRD003','2012-12-26');

















